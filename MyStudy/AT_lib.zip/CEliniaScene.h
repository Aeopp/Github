#pragma once
#include "include/Scene/CScene.h"

class CEliniaScene
{
};

