#pragma once
#include "include/Object/StaticObj.h"

class Bar : public CStaticObj
{
	/*void Render(HDC hDC, float fDeltaTime) override{
		CObj
	}*/
};

