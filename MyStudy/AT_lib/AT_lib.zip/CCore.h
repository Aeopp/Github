#pragma once
#include "Game.h"

class CCore
{
private:
	static inline CCore* m_pInst;
	static inline bool m_bLoop = true;
	HINSTANCE m_hInst;
	HWND m_hWnd; 
	Resolution m_tRs;
public:
	static CCore* GetInst();
	static void DestroyInst();
	bool Init(HINSTANCE hInst);
	int Run();
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT message,
	WPARAM wParam, LPARAM lParam); 
private :
	ATOM MyRegisterClass(); 
	BOOL Create();
private:
	CCore();
	~CCore()noexcept=default ;
};

