#pragma once

#include <Windows.h>
#include <list>
#include <vector>
#include <unordered_map>
#include "Macro.h"
#include "resource.h"
#include "Types.h"
using namespace std;


