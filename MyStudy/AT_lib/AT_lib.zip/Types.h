#pragma once

struct Resolution {
	unsigned int iW;
	unsigned int iH;
};
