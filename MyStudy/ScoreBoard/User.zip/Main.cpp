#include "LinkedList.h"
using T = User;

int main()
{
	using namespace std;

	LinkedList Test;

	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());
	Test.front_Insert(User());

	cout << Test << endl;
	cout << "==============================\n\n";
//	Test.Sort();

	//cout << Test;
	Test.Sort(Test.getSize());
	cout << Test;
}
