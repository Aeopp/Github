#pragma once
#include <iostream>
#include <string>
#include <random>
#include <algorithm>
#include <iomanip>
struct User
{
public:	
	User();
	int32_t Age;
	std::string Name;
	int32_t Math;
	int32_t Eng;
	int32_t Kor;
	float Sum;
	float Average;
	inline void Print()const;
	inline bool operator<=(const User& Rhs)const;
	inline bool operator>=(const User& Rhs)const;
	inline bool operator!=(const User&Rhs)const;
	friend inline std::ostream& operator<<(std::ostream& ConOut, const User& Rhs);
};
inline  std::ostream& operator<<(std::ostream& ConOut, const User& Rhs)
{
	Rhs.Print();
	return ConOut;
};
inline void User::Print() const
{
	std::cout << "\t" << "�̸� : " << Name  << "\t���� : " << Age
		<< "\t���� :\t" << Math << "\t���� : " << Eng << "\t���� : " << Kor << "\t���� : " << Sum
		<< "\t��� : " << Average << std::endl;
}

inline bool User::operator<=(const User& Rhs)const
{
	return this->Sum <= Rhs.Sum;
};
inline bool User::operator>=(const User& Rhs)const 
{
	return(!(*this <= Rhs));
};
inline bool User::operator!=(const User&Rhs)const 
{
	return( this->Name != Rhs.Name);
};
inline User::User()
{
	static std::random_device rd;
	static std::mt19937 gen(rd());
	static std::uniform_int_distribution<int32_t> dis(0, 100);

	Age = std::clamp((dis(gen)%21), 14, 20);
	Math = dis(gen);
	Eng = dis(gen);
	Kor = dis(gen);
	Sum = 0 + Math + Eng + Kor;
	Average = static_cast<float>(Sum /= 3);
};
