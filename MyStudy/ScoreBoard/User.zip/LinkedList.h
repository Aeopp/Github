#pragma once
#include <iostream>
#include <cassert>
#include <string>
#include <functional>
#include "User.h"
struct Node;
using T = User;
namespace Utility
{
	template<typename T>
	inline void SAFE_DELETE(T*& Param)
	{
		assert(Param && " Param nullptr");
		if (Param != nullptr);
		delete Param;
	};
	template<typename T>
	inline void Swap(T&& Lhs, T&& Rhs)
	{
		std::remove_reference_t<T> Temp = Lhs;
		Lhs = std::move(Rhs);
		Rhs = std::move(Temp);
	};
	template <>
	inline void Swap
	(int32_t& Lhs, int32_t& Rhs)
	{
		Lhs = Lhs ^ Rhs;
		Rhs = Lhs ^ Rhs;
		Lhs = Lhs ^ Rhs;
	};
};

class LinkedList
{
	struct Node;
	using T = User;
	using FunType = std::function<bool(const T&Lhs, const T&Rhs)>;
private:
	struct Node
	{
	public:
		friend class LinkedList;
	private:
		T Data = User();
		Node* Prev = nullptr;
		Node* Next = nullptr;
		Node(const T& ParamData) :Data(ParamData) {};
		Node() {};
	};
	Node* Head;
	Node* Tail;

	FunType SortCompare;
	
	inline Node* SearchNode(const T& Search)const;;
public:
	LinkedList();;
	/*virtual*/ ~LinkedList()
	{
		Node* Target = Head->Next;

		while (Target && Target != Tail)
		{
			Node* NextTarget = Target->Next;
			Utility::SAFE_DELETE(Target);
			Target = NextTarget;
		};

		Utility::SAFE_DELETE(Head /*Target Is Head*/);

		if (Tail != nullptr)
			Utility::SAFE_DELETE(Tail);
	};

	void SortInsert(const T& Data)const;

	inline void Sort(const size_t ConSize);
	inline Node* nthNode(uint32_t offset)const;
	inline void SetSortFunction(const FunType&);
	inline void Insert(const T& Search, const T& Data)const;;
	inline void front_Insert(const T& Data)const;;
	inline void back_Insert(const T& Data)const;;
	inline void InsertHelper(const T& Data, Node*Mid, Node*Rhs)const;
	inline void Erase(const T& Search)const;
	inline bool Swap(const T& LhsTarget, const T& RhsTarget);
	inline void Print()const;;
	inline bool IsEmpty() const;;
	inline T GetData(const T& Search)const;;
	inline void SetData(const T& Search, const T& ParamSetUp)const;
	inline T& operator[](uint32_t offset);
	inline size_t getSize()const ;

	friend inline std::ostream& operator<<(std::ostream& Conout, const LinkedList& Llist);
};

inline std::ostream& operator<<(std::ostream& Conout, const LinkedList& Llist)
{
	Llist.Print();
	return Conout;
	// TODO: ���⿡ ��ȯ ������ �����մϴ�.
}
inline LinkedList::LinkedList() : Head(new Node), Tail(new Node)
{
	Head->Prev = nullptr;
	Tail->Next = nullptr;

	Head->Next = Tail;
	Tail->Prev = Head;
	
	SetSortFunction([](const T& Lhs,const T& Rhs)->bool 
	{
		return Lhs <= Rhs; 
	});
};

inline T LinkedList::GetData(const T & Search) const
{
	Node* RetVal = SearchNode(Search);
	return RetVal->Data;
};

inline void LinkedList::SetData(const T & Search, const T & ParamSetUp) const
{
	SearchNode(Search)->Data = ParamSetUp;
	// TODO :: �����͸� �����ͼ� �����ΰ��� �Ѵ�........
}

inline T &LinkedList::operator[](uint32_t offset)
{
	// TODO: ���⿡ ��ȯ ������ �����մϴ�.
	return nthNode(offset)->Data;
}
inline size_t LinkedList::getSize() const
{
	size_t RetVal = 0;
	auto* Current = Head->Next;

	while (Current!=Tail)
	{
		RetVal++;
		Current = Current->Next;
	};

	return RetVal;
};

inline void LinkedList::InsertHelper(const T& Data, Node * Lhs, Node * Rhs) const
{
	Node* Inserter = new Node(Data);/*(T Type Param Pass )*/

	Lhs->Next = Inserter;
	Inserter->Prev = Lhs;

	Rhs->Prev = Inserter;
	Inserter->Next = Rhs;
	
}
inline void LinkedList::Erase(const T & Search)const
{
	Node* Target = SearchNode(Search);
	Node* NPrev = Target->Prev;
	Node* NNext = Target->Next;
	NPrev->Next = NNext;
	NNext->Prev = NPrev;

	Utility::SAFE_DELETE(Target);
};
inline void LinkedList::Print() const
{
	Node* PrintNode = Head->Next;
	while (PrintNode&&PrintNode != Tail)
	{
		std::cout << PrintNode->Data << std::endl;
		PrintNode = PrintNode->Next;
	};
};

inline bool LinkedList::IsEmpty() const
{
	return (Head->Next == Tail);
};

inline LinkedList::Node*LinkedList::SearchNode(const T& Search)const
{
	Node* SearchPrev = Head;
	Node* SearchNext;

	while (SearchPrev && SearchPrev->Data != Search)
	{
		SearchPrev = SearchPrev->Next;
	};
	if (SearchPrev == nullptr)
	{
		assert(false && " �����͸� ã�� �� �����ϴ�.");
		return nullptr;
	};
	return SearchPrev;
}

inline bool LinkedList::Swap(const T & LhsTarget, const T & RhsTarget)
{
	auto* Lhs = SearchNode(LhsTarget);
	auto* Rhs = SearchNode(RhsTarget);

	assert((Lhs&&Rhs) && "Swap Fail");
	/*return false */

	Utility::Swap(Lhs->Data, Rhs->Data);
	return true;
}

inline void LinkedList::SortInsert(const T & Data) const
{
	if (IsEmpty())
	{
		front_Insert(Data);
		return; 
	};

	auto Current = Head->Next; 

	while (SortCompare(Data, Current->Data))
	{
		Current = Current->Next;
		if (Current == Tail)break;
	};
	InsertHelper(Data, Current->Prev, Current); 
}

inline void LinkedList::Sort( const size_t ConSize) 
{
	int32_t i, j,n;  
	T key;

	auto &Ref  =*this;
	for (i = 1; i < ConSize; i++) {
		key = Ref[i];
		for (j = i - 1; j >= 0 && SortCompare(Ref[j] ,key); j--) {
			Ref[j + 1] = Ref[j];
		}
		Ref[j + 1] = key;
	}
};

inline LinkedList::Node* LinkedList::nthNode(uint32_t offset)const
{
	Node* Current = Head->Next;

	if (offset == 0 && Head->Next!=Tail) return Current;

	while (offset--&& Current->Next != Tail)
	{
		Current = Current->Next;
	};

	if (Current == Tail)
		return  nullptr; 

	return Current;
}

inline void LinkedList::SetSortFunction(const FunType & SetSortFun)
{
	SortCompare = SetSortFun;
}

inline void LinkedList::Insert(const T & Search, const T & Data) const
{
	Node* SearchPrev = SearchNode(Search);

	Node* SearchNext = SearchPrev->Next;
	InsertHelper(Data, SearchPrev, SearchNext);

}
inline void LinkedList::back_Insert(const T & Data) const
{
	InsertHelper(Data, Tail->Prev, Tail);

	
};
inline void LinkedList::front_Insert(const T & Data) const
{
	InsertHelper(Data, Head, Head->Next);
	
}
