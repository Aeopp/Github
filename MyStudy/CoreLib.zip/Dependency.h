#pragma once
#pragma comment(lib,"fmod_vc.lib")
#pragma comment(lib,"CoreLib.lib")