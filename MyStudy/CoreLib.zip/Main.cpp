//
//int WINAPI wWinMain
//(HINSTANCE hInstance,
//	HINSTANCE hPrevInstance,
//	LPWSTR lpCmdLine,
//	int nCmdShow)
//{
//	_Tester win;
//
//	if (win.SetWindow(hInstance))
//	{
//		win.Run();
//	}
//}
