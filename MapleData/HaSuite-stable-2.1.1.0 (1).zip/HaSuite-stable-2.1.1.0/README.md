HaSuite is a collection of tools for MapleStory.

To build HaSuite, you need at least Visual Studio 2013 (.NET 4.5.1 and Visual C++ Runtimes 2013). You must build it in AnyCPU mode, otherwise you will have to copy apng32.dll/apng64.dll from the AnyCPU build directory to the correct path.

To run HaSuite, you need .NET 4.5.1 and Visual C++ Redistributable 2013.